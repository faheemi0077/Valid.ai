"use client";

import { useState } from "react";
import {
  ChevronDown,
  ChevronRight,
  Calendar,
  XCircle,
  CheckCircle2,
  AlertTriangle,
  Zap,
} from "lucide-react";

interface ResultsPanelProps {
  data: Record<string, unknown>;
}

function DecisionBadge({ decision }: { decision: string }) {
  const config: Record<string, { bg: string; text: string; icon: React.ReactNode }> = {
    REJECT: {
      bg: "bg-destructive/15",
      text: "text-destructive",
      icon: <XCircle className="h-5 w-5" />,
    },
    QUALIFIED: {
      bg: "bg-primary/15",
      text: "text-primary",
      icon: <CheckCircle2 className="h-5 w-5" />,
    },
    PRIORITY: {
      bg: "bg-success/15",
      text: "text-success",
      icon: <Zap className="h-5 w-5" />,
    },
    NURTURE: {
      bg: "bg-warning/15",
      text: "text-warning",
      icon: <AlertTriangle className="h-5 w-5" />,
    },
  };

  const c = config[decision] || config.QUALIFIED;

  return (
    <span
      className={`inline-flex items-center gap-2 rounded-full px-4 py-2 text-sm font-semibold ${c.bg} ${c.text}`}
    >
      {c.icon}
      {decision}
    </span>
  );
}

function ScoreGauge({ score }: { score: number }) {
  const color =
    score >= 70
      ? "text-success"
      : score >= 40
        ? "text-warning"
        : "text-destructive";

  const barColor =
    score >= 70
      ? "bg-success"
      : score >= 40
        ? "bg-warning"
        : "bg-destructive";

  return (
    <div className="flex flex-col gap-2">
      <div className="flex items-baseline justify-between">
        <span className="text-xs text-muted-foreground">Lead Score</span>
        <span className={`font-mono text-2xl font-bold ${color}`}>
          {score}
        </span>
      </div>
      <div className="h-2 w-full overflow-hidden rounded-full bg-muted">
        <div
          className={`h-full rounded-full ${barColor} transition-all duration-700`}
          style={{ width: `${score}%` }}
        />
      </div>
    </div>
  );
}

function CollapsibleSection({
  title,
  children,
  defaultOpen = false,
}: {
  title: string;
  children: React.ReactNode;
  defaultOpen?: boolean;
}) {
  const [open, setOpen] = useState(defaultOpen);

  return (
    <div className="rounded-lg border border-border">
      <button
        type="button"
        onClick={() => setOpen(!open)}
        className="flex w-full items-center justify-between px-4 py-3 text-sm font-medium text-foreground hover:bg-muted/50"
      >
        {title}
        {open ? (
          <ChevronDown className="h-4 w-4 text-muted-foreground" />
        ) : (
          <ChevronRight className="h-4 w-4 text-muted-foreground" />
        )}
      </button>
      {open && <div className="border-t border-border px-4 py-3">{children}</div>}
    </div>
  );
}

function JsonBlock({ data }: { data: unknown }) {
  return (
    <pre className="max-h-64 overflow-auto rounded-md bg-muted p-3 font-mono text-xs text-muted-foreground">
      {JSON.stringify(data, null, 2)}
    </pre>
  );
}

export function ResultsPanel({ data }: ResultsPanelProps) {
  const scoreData = data.score as Record<string, unknown> | undefined;
  const decisionData = data.decision as Record<string, unknown> | undefined;
  const explanationData = data.explanation as Record<string, unknown> | undefined;
  const buyProbData = data.buy_probability as Record<string, unknown> | undefined;

  const score = (scoreData?.score as number) ?? 0;
  const decision = (scoreData?.decision as string) ?? "UNKNOWN";
  const confidence = (scoreData?.confidence as number) ?? 0;
  const reasons = (scoreData?.reasons as string[]) ?? [];
  const showLink = (decisionData?.show_link as boolean) ?? false;
  const linkReason = (decisionData?.reason as string) ?? "";
  const explanation = (explanationData?.explanation as string) ?? "";
  const buyProbability = (buyProbData?.buy_probability as number) ?? 0;

  return (
    <div className="flex flex-col gap-6">
      {/* Header: Decision + Score */}
      <div className="flex flex-col gap-6 rounded-xl border border-border bg-card p-6">
        <div className="flex flex-col items-start justify-between gap-4 sm:flex-row sm:items-center">
          <div className="flex flex-col gap-1">
            <h2 className="text-lg font-semibold text-foreground">
              Analysis Result
            </h2>
            <p className="text-sm text-muted-foreground">
              Confidence: {(confidence * 100).toFixed(0)}%
            </p>
          </div>
          <DecisionBadge decision={decision} />
        </div>

        <ScoreGauge score={score} />

        {/* Key Metrics */}
        <div className="grid grid-cols-2 gap-4 sm:grid-cols-3">
          <div className="flex flex-col gap-1 rounded-lg bg-muted/50 p-3">
            <span className="text-xs text-muted-foreground">
              Buy Probability
            </span>
            <span className="font-mono text-lg font-semibold text-foreground">
              {(buyProbability * 100).toFixed(0)}%
            </span>
          </div>
          <div className="flex flex-col gap-1 rounded-lg bg-muted/50 p-3">
            <span className="text-xs text-muted-foreground">
              Calendly Link
            </span>
            <span
              className={`flex items-center gap-1.5 text-lg font-semibold ${showLink ? "text-success" : "text-muted-foreground"}`}
            >
              <Calendar className="h-4 w-4" />
              {showLink ? "Show" : "Hide"}
            </span>
          </div>
          <div className="col-span-2 flex flex-col gap-1 rounded-lg bg-muted/50 p-3 sm:col-span-1">
            <span className="text-xs text-muted-foreground">Decision</span>
            <span className="text-sm font-medium text-foreground">
              {linkReason}
            </span>
          </div>
        </div>
      </div>

      {/* Explanation */}
      {explanation && (
        <div className="rounded-xl border border-border bg-card p-6">
          <h3 className="mb-2 text-sm font-medium text-muted-foreground">
            Explanation
          </h3>
          <p className="text-sm leading-relaxed text-foreground">
            {explanation}
          </p>
        </div>
      )}

      {/* Reasons */}
      {reasons.length > 0 && (
        <div className="rounded-xl border border-border bg-card p-6">
          <h3 className="mb-3 text-sm font-medium text-muted-foreground">
            Scoring Reasons
          </h3>
          <ul className="flex flex-col gap-2">
            {reasons.map((reason, i) => (
              <li
                key={i}
                className="flex items-start gap-2 text-sm text-foreground"
              >
                <span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-primary" />
                {reason}
              </li>
            ))}
          </ul>
        </div>
      )}

      {/* Collapsible Raw Data */}
      <div className="flex flex-col gap-2">
        <CollapsibleSection title="Intent Signals">
          <JsonBlock data={data.signals} />
        </CollapsibleSection>

        <CollapsibleSection title="Buy Probability">
          <JsonBlock data={data.buy_probability} />
        </CollapsibleSection>

        <CollapsibleSection title="Disqualifiers">
          <JsonBlock data={data.disqualifiers} />
        </CollapsibleSection>

        <CollapsibleSection title="Full Score Object">
          <JsonBlock data={data.score} />
        </CollapsibleSection>

        <CollapsibleSection title="Calendly Decision">
          <JsonBlock data={data.decision} />
        </CollapsibleSection>
      </div>
    </div>
  );
}
