import {
  Brain,
  BarChart3,
  ShieldAlert,
  Target,
  GitBranch,
  MessageSquare,
} from "lucide-react";

const steps = [
  { icon: Brain, label: "Extract Signals", description: "Parse intent from raw text" },
  { icon: BarChart3, label: "Buy Probability", description: "Estimate purchase likelihood" },
  { icon: ShieldAlert, label: "Disqualifiers", description: "Detect hard/soft blockers" },
  { icon: Target, label: "Score Lead", description: "0-100 composite score" },
  { icon: GitBranch, label: "Route Decision", description: "Reject / Qualified / Priority" },
  { icon: MessageSquare, label: "Explain", description: "Generate human-readable summary" },
];

export function PipelineSteps({ isActive }: { isActive: boolean }) {
  return (
    <div className="flex flex-col gap-3">
      <h3 className="text-xs font-medium text-muted-foreground uppercase tracking-wider">
        Pipeline Steps
      </h3>
      <div className="flex flex-col gap-1">
        {steps.map((step, i) => {
          const Icon = step.icon;
          return (
            <div
              key={i}
              className={`flex items-center gap-3 rounded-lg px-3 py-2 transition-colors ${
                isActive
                  ? "animate-pulse bg-muted/50"
                  : "bg-transparent"
              }`}
            >
              <Icon className="h-4 w-4 shrink-0 text-primary" />
              <div className="flex flex-col">
                <span className="text-sm font-medium text-foreground">
                  {step.label}
                </span>
                <span className="text-xs text-muted-foreground">
                  {step.description}
                </span>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
