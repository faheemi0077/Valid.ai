"use client";

import { useState } from "react";
import { Loader2, Send } from "lucide-react";

interface AnalyzeFormProps {
  onResult: (data: Record<string, unknown>) => void;
  onError: (error: string) => void;
  onLoading: (loading: boolean) => void;
}

const EXAMPLE_LEADS = [
  "Hi! I'm the Head of RevOps at Acme. We're actively evaluating tools this month, I own the budget, and we want to get started within 2-3 weeks. Can you share pricing and help us set up a quick call to discuss rollout?",
  "I'm a college student doing research on CRM tools for a class project. I don't have any budget and I'm not looking to buy anything, just gathering information for my paper.",
  "We're interested in your platform but currently locked into a 3-year contract with Salesforce. Our renewal isn't until 2027, so we can't switch vendors right now even if we wanted to.",
];

export function AnalyzeForm({ onResult, onError, onLoading }: AnalyzeFormProps) {
  const [text, setText] = useState("");
  const [loading, setLoading] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!text.trim() || loading) return;

    setLoading(true);
    onLoading(true);
    onError("");

    try {
      const response = await fetch("https://validaibackend-production.up.railway.app/analyze-lead", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ text: text.trim() }),
      });

      const data = await response.json();

      if (!response.ok) {
        onError(data.error || "Analysis failed");
        return;
      }

      onResult(data);
    } catch {
      onError("Failed to connect to the analysis API");
    } finally {
      setLoading(false);
      onLoading(false);
    }
  }

  return (
    <form onSubmit={handleSubmit} className="flex flex-col gap-4">
      <div className="flex flex-col gap-2">
        <label
          htmlFor="lead-text"
          className="text-sm font-medium text-foreground"
        >
          Lead Paragraph
        </label>
        <textarea
          id="lead-text"
          value={text}
          onChange={(e) => setText(e.target.value)}
          placeholder="Paste the inbound lead message here..."
          rows={5}
          className="w-full resize-none rounded-lg border border-border bg-muted px-4 py-3 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring"
          disabled={loading}
        />
      </div>

      <div className="flex flex-col gap-2">
        <p className="text-xs text-muted-foreground">Try an example:</p>
        <div className="flex flex-wrap gap-2">
          {EXAMPLE_LEADS.map((lead, i) => (
            <button
              key={i}
              type="button"
              onClick={() => setText(lead)}
              disabled={loading}
              className="rounded-md border border-border bg-secondary px-3 py-1.5 text-xs text-muted-foreground transition-colors hover:bg-muted hover:text-foreground disabled:opacity-50"
            >
              {["Priority Lead", "Student (Reject)", "Competitor Lock-in"][i]}
            </button>
          ))}
        </div>
      </div>

      <button
        type="submit"
        disabled={!text.trim() || loading}
        className="flex items-center justify-center gap-2 rounded-lg bg-primary px-6 py-3 text-sm font-medium text-primary-foreground transition-opacity hover:opacity-90 disabled:opacity-50"
      >
        {loading ? (
          <>
            <Loader2 className="h-4 w-4 animate-spin" />
            Analyzing (6 pipeline steps)...
          </>
        ) : (
          <>
            <Send className="h-4 w-4" />
            Analyze Lead
          </>
        )}
      </button>
    </form>
  );
}
