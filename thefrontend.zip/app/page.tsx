"use client";

import { useState } from "react";
import { AlertTriangle } from "lucide-react";
import { AnalyzeForm } from "@/components/analyze-form";
import { ResultsPanel } from "@/components/results-panel";
import { PipelineSteps } from "@/components/pipeline-steps";

export default function Home() {
  const [result, setResult] = useState<Record<string, unknown> | null>(null);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  return (
    <main className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-6 py-4">
          <div className="flex items-center gap-3">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary">
              <span className="font-mono text-sm font-bold text-primary-foreground">
                V
              </span>
            </div>
            <h1 className="text-lg font-semibold text-foreground">ValidAI</h1>
          </div>
          <span className="rounded-full border border-border px-3 py-1 text-xs text-muted-foreground">
            Mistral-powered
          </span>
        </div>
      </header>

      <div className="mx-auto max-w-6xl px-6 py-8">
        <div className="mb-8 flex flex-col gap-1">
          <h2 className="text-2xl font-bold tracking-tight text-foreground text-balance">
            Lead Qualification Pipeline
          </h2>
          <p className="text-sm text-muted-foreground">
            Paste an inbound lead message below. The AI pipeline will extract
            signals, score the lead, and make a routing decision.
          </p>
        </div>

        <div className="grid gap-8 lg:grid-cols-3">
          {/* Left: Form + Pipeline Info */}
          <div className="flex flex-col gap-8 lg:col-span-1">
            <div className="rounded-xl border border-border bg-card p-6">
              <AnalyzeForm
                onResult={(data) => {
                  setResult(data);
                  setError("");
                }}
                onError={setError}
                onLoading={setLoading}
              />
            </div>

            <div className="rounded-xl border border-border bg-card p-6">
              <PipelineSteps isActive={loading} />
            </div>
          </div>

          {/* Right: Results */}
          <div className="lg:col-span-2">
            {error && (
              <div className="flex items-start gap-3 rounded-xl border border-destructive/30 bg-destructive/10 p-4">
                <AlertTriangle className="mt-0.5 h-5 w-5 shrink-0 text-destructive" />
                <div className="flex flex-col gap-1">
                  <p className="text-sm font-medium text-destructive">
                    Analysis Failed
                  </p>
                  <p className="text-sm text-muted-foreground">{error}</p>
                </div>
              </div>
            )}

            {result && !error ? (
              <ResultsPanel data={result} />
            ) : !error ? (
              <div className="flex h-full items-center justify-center rounded-xl border border-dashed border-border p-12">
                <div className="flex flex-col items-center gap-3 text-center">
                  <div className="flex h-12 w-12 items-center justify-center rounded-full bg-muted">
                    <span className="text-lg text-muted-foreground">?</span>
                  </div>
                  <p className="text-sm text-muted-foreground">
                    Enter a lead message and click Analyze to see results
                  </p>
                </div>
              </div>
            ) : null}
          </div>
        </div>
      </div>
    </main>
  );
}
