import { NextResponse } from "next/server";
import { callMistral } from "@/lib/mistral";
import {
  promptIntent,
  probabilityPrompt,
  disqualifierPrompt,
  scoringPrompt,
  decisionPrompt,
  explanationPrompt,
  disqualifierSchema,
} from "@/lib/prompts";

export const maxDuration = 60;

export async function POST(request: Request) {
  try {
    if (!process.env.MISTRAL_API_KEY) {
      return NextResponse.json(
        { error: "MISTRAL_API_KEY is not set" },
        { status: 500 }
      );
    }

    const { text } = await request.json();

    if (!text || typeof text !== "string" || text.trim().length === 0) {
      return NextResponse.json(
        { error: "Please provide lead text to analyze" },
        { status: 400 }
      );
    }

    const rawText = text.trim();

    // Step 1: Extract intent signals
    const signals = await callMistral(promptIntent, rawText, 0.1);

    // Step 2: Estimate buy probability
    const buyProbability = await callMistral(
      probabilityPrompt,
      JSON.stringify(signals),
      0.1
    );

    // Step 3: Detect disqualifiers
    const disqualifiers = await callMistral(
      disqualifierPrompt,
      JSON.stringify({
        raw_text: rawText,
        signals,
        schema: disqualifierSchema,
      }),
      0.1
    );

    // Step 4: Score the lead
    const score = await callMistral(
      scoringPrompt,
      JSON.stringify({
        signals,
        buy_probability: buyProbability,
        disqualifiers,
      }),
      0.1
    );

    // Step 5: Make decision (Calendly link)
    const scoreObj = score as Record<string, unknown>;
    const decision = await callMistral(
      decisionPrompt,
      JSON.stringify({
        ...scoreObj,
        disqualifiers,
      }),
      0.0
    );

    // Step 6: Explain decision
    const decisionObj = decision as Record<string, unknown>;
    const explanation = await callMistral(
      explanationPrompt,
      JSON.stringify({
        ...scoreObj,
        show_link: decisionObj.show_link,
      }),
      0.2
    );

    return NextResponse.json({
      signals,
      buy_probability: buyProbability,
      disqualifiers,
      score,
      decision,
      explanation,
    });
  } catch (error) {
    const message =
      error instanceof Error ? error.message : "An unexpected error occurred";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
